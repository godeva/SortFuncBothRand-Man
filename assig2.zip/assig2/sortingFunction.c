/** file sortingFunction.c
* @author Goutham Deva
*
* Program uses a function to sort an array of integers into ascending order.
* The program also has two functions, one for generating a (pseudo) random
* integers from zero to some specified maximum inclusively and the other for
* filling an array with random numbers taken from the numGenerator function.
*
*/

#include <stdio.h>
#include <stdlib.h>

/*Stores function prototype for sortingFunction.c*/
#include "sortingFunction.h"

/** sortingFunction sorts array in ascending order of numbers using the bubble sort algorithm.
* Algorithm goes through each two element next to each other and compares.
* If first number is larger, it switches order with second element; if smaller, it it stays
* in the same place. Repeats process till all elements in array are checked
* @param arrayOfnum array where data from command line is stored
* @param arraysize size of the array so the function knows when to stop
*/

void sortingFunction(int arrayOfnum[], int arraysize) {
  int i, j, k; // Keeps track of first element, second element, and swapping numbers in array

  for (i = 0; i < arraysize; i++) // Terminates first element in array till array size reaches max
  {
    for (j = 0; j < arraysize - i - 1; j++) // Terminates seconds element counter till array size reaches max
    {
      if (arrayOfnum[j] > arrayOfnum[j+1]) /* Swapping of numbers in array from acending order if first element is larger then second element in the array */
      {
        k = arrayOfnum[j]; // Sets number in array postion
        arrayOfnum[j] = arrayOfnum[j+1]; // Changes positons in array
        arrayOfnum[j+1] = k; // Sets that number to that changed positon
      }
    }
  }
}

/** numGenerator Generates a (pseudo) random integer from zero to some specified maximum,
* inclusive which means including the endpoints of an interval of numbers.
* @param specificMAX Maximum value that number can generate to
* @return randnum random number
*/

int numGenerator(int specificMAX)
{
  int i; // Keeps track of loops till array size max
  int randnum; // Sets random number

  randnum = rand() % (specificMAX + 1); /* Generates random number, +1 added to specfied max value so that range is inclusive */

  return randnum;
}


/** randomArray Fills an array of specified size with random numbers from zero to
* a specified maximum, also inclusive.
* @param arrayOfnum Array where data from numGenerator is stored
* @param arraysize Size of the array so the function knows when to stop
* @param specificMAX Maximum value that number can generate to
*/

void randomArray(int arrayOfnum[], int arraysize, int specificMAX)
{
  int numOfElt; // Holds number of elements stored currently in the array
  for (numOfElt = 0; numOfElt < arraysize; numOfElt++) // Terminates when arraysize is full
  {
    arrayOfnum[numOfElt] = numGenerator(specificMAX); // Stores random number in each element of array
  }
}
