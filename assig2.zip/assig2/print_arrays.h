/** File print_arrays.h
* @author Mike Ciaraldi & Goutham Deva
*
* Header file for functions that print arrays.
*/

#ifndef PRINT_ARRAYS_H
#define PRINT_ARRAYS_H

#include <stdio.h>

// function prototypes:

void print_int_array(int a[], int num_entries);
void print_double_array(double b[], int num_entries);
int readToIntArray(int argc, const char* argv[], int arrayOfnum[], int arraysize);

#endif
