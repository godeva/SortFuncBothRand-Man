/** File sortingFunction.h
* @author Goutham Deva
*
* Header file for functions that sorts an array of integers into ascending order.
*/

#ifndef SORTINGFUNCTION_H
#define SORTINGFUNCTION_H

#include <stdio.h>

// function prototypes:

void sortingFunction(int arrayOfnum[], int arraysize);
int numGenerator(int arraysize);
void randomArray(int arrayOfnum[], int arraysize, int specificMAX);

#endif
