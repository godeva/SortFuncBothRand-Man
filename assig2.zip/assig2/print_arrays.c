/** file print_arrays.c
* @author Mike Ciaraldi & Goutham Deva
*
* Functions for printing and storing arrays.
*/

#include <stdio.h>
#include <stdlib.h>

/*Function prototypes stored for Print_int_array, print_double_array, & readToIntArray*/
#include "print_arrays.h"

/** Print an array of ints, one per line.
* @param a an array to print
* @param num_entries Number of entries in the array
* @return Array of integers
*/

void print_int_array(int a[], int num_entries)
{
  int i; // Loop counter

  for (i = 0; i < num_entries; i++) // Terminates loop when all elements are entries and max array size is reached
  {
    printf("%d\n", a[i]); // Prints each element/integer of the array
  }
}

/** print_double_array: Prints an array of doubles, one per line
* @param b an array to print
* @param num_entries Number of double data type entries in the array
* @return Array of doubles
*/

void print_double_array(double b[], int num_entries)
{
  int j; // Loop counter

  for (j = 0; j < num_entries; j++) // Terminates loop when all elements are entries and max array size is reached
  {
    printf("%f\n", b[j]); // Prints each element/double of the array
  }
}

/** readToIntArray for storing arrays outside of main program.
* @param argc Automatically fills in the number of words on the command line
* @param argv Points to an array of character strings, representing the words in the command line
* @param arrayOfnum Array where data from command line is stored
* @param arraysize Size of the array so the function knows when to stop
* @return numOfelt Indicating the number of elements stored in current array
*/

int readToIntArray(int argc, const char* argv[], int arrayOfnum[], int arraysize)
{
  int numOfElt = 0; // Holds number of elements stored currently in the array

  while (numOfElt < (argc-1) && numOfElt < arraysize) // Terminates when arraysize max has reached
  {
    arrayOfnum[numOfElt] = atoi(argv[numOfElt + 1]); // Gets integer data from command line and stores it in array
    numOfElt++;
  }
  return numOfElt;
}
