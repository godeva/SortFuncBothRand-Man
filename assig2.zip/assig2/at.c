/** file at.c
* @author Mike Ciaraldi and Goutham Deva
*
* Program to demonstrate fixed-size arrays in C.
* Modified to also print double data type values in an array
*/

/*Function prototypes stored for Print_int_array, print_double_array, & readToIntArray*/
#include "print_arrays.h"

/*Declared array used in print_int_array to store integer numbers*/
#define SAMPLE_INT_ARRAY_SIZE (10)
/*Declared array used in print_double_array to store double data type numbers*/
#define DOUBLE_ARRAY_SIZE (10)

/** Main program for demonstrating both arrays. It fills both int and double arrays and prints them.
* @return 0, Indicating success.
*/

int main() //Runs at.c program
{
  int i; // Loop counter
  int j; // Loop counter for double data type
  int a[SAMPLE_INT_ARRAY_SIZE]; // Sample array for demonstration
  double b[DOUBLE_ARRAY_SIZE]; /*Double array that stores double data types through print_double_array function*/

  // Fills the array with consecutive integers
  for (i = 0; i < SAMPLE_INT_ARRAY_SIZE; i++) a[i] = i;

  // Function prints out numbers in array
  print_int_array(a, SAMPLE_INT_ARRAY_SIZE);

  // Fills double array with doubles data type numbers
  for (j = 0; j < DOUBLE_ARRAY_SIZE; j++) b[j] = (double)j;

  // Prints out double data type numbers
  print_double_array(b, DOUBLE_ARRAY_SIZE);

  return 0; // Success!
}
