/** file at3.c
* @author Goutham Deva
*
* This program demonstrates the knowledge of creating random arrays and sorting them.
* Calling functions from sortingFunction.c, the main function creates random numbers
* in the array and prints them out. It then takes those stored numbers and sorts them
* in ascending order and then prints out the sorted array.
*
*/

/*Function prototypes stored for Print_int_array, print_double_array, & readToIntArray*/
#include "print_arrays.h"

/*Declaring array used in RANDOMREADTOINTARRAY at a constant size*/
#define RANDOMREADTOINTARRAY_ARRAY_SIZE (10)
/*Declaring array to be used for inclusive max range for numGenerator function*/
#define SPECIFIC_MAX (100)

/** Main program for demonstrating random and sorted arrays. Program fills an array of random numbers
* and prints the array is before it's sorted and prints after the array is sorted in ascending order.
* @return 0, Indicating success
*/

int main () /*Runs program*/
{
  int arrayOfnum[RANDOMREADTOINTARRAY_ARRAY_SIZE]; // Fill the array with consecutive integers
  int numOfelt = RANDOMREADTOINTARRAY_ARRAY_SIZE; /*Assigns numbers in RANDOMREADTOINTARRAY_ARRAY_SIZE to numOfelt*/

  randomArray(arrayOfnum, RANDOMREADTOINTARRAY_ARRAY_SIZE, SPECIFIC_MAX); // Returns array of random numbers from 0 to SPECIFIC_MAX size
  printf("Original random numbers!\n");
  print_int_array(arrayOfnum, numOfelt); // Prints out the current array of random numbers before sorting
  sortingFunction(arrayOfnum, numOfelt); // Sorts array of random numbers in ascending order
  printf("Sorted random numbers in ascending order!\n");
  print_int_array(arrayOfnum, numOfelt); //Prints out the sorted array of random numbers

  return 0; // Success!
}
