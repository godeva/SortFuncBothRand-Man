/** file at2.c
* @author Goutham Deva
*
* This program demonstrates the knowledge of taking data from command line
* and storing in array. Calling functions from print_arrays.c and sortingFunction.c,
* the main function takes the numbers stored in the array and prints them out.
* It then takes those stored numbers and sorts them in ascending order and then
* prints out the sorted array.
*
*/

/*Function prototypes stored for Print_int_array, print_double_array, & readToIntArray*/
#include "print_arrays.h"

/*Declaring array used in readToIntArray at a constant size*/
#define READTOINTARRAY_ARRAY_SIZE (10)

/** Main program for demonstrating sorted arrays. Program fills an array using the command line
* and prints the array before it's sorted and prints after the array is sorted in ascending order.
* @param argc automatically fills in with the number of words on the command line
* @param argv points to an array of character strings, representing the words in the command line
* @return sorted array of integers in ascending order
* @return 0, Indicating success
*/

int main (int argc, const char* argv[]) /*Runs program*/
{
  int arrayOfnum[READTOINTARRAY_ARRAY_SIZE]; // Fills the empty array with consecutive integers
  int numOfelt = 0; // Holds number of elements stored currently in the array

  if (argc < 2) // check that there was an entry
  {
    printf("Must enter a number on the command line!\n");
    return 1; //Indicate failure
  }

  numOfelt = readToIntArray(argc, argv, arrayOfnum, READTOINTARRAY_ARRAY_SIZE); /*Assigns stored numbers in READTOINTARRAY_ARRAY_SIZE to numOfelt*/

  if (argc-1 > READTOINTARRAY_ARRAY_SIZE) /*Checks if numbers entered reaches more than READTOINTARRAY_ARRAY_SIZE*/
  {
    printf("This program can only test a max number of %d numbers\n", READTOINTARRAY_ARRAY_SIZE);
  }

  printf("Original numbers!\n");
  print_int_array(arrayOfnum, numOfelt); // Prints out the current array stored in numOfelt before sorting
  sortingFunction(arrayOfnum, numOfelt); // Sorts numOfelt array numbers in ascending order
  printf("Sorted numbers in ascending order!\n");
  print_int_array(arrayOfnum, numOfelt); // Prints out the current array stored in numOfelt after sorting

  return 0; // Success!
}
